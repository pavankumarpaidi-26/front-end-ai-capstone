import React from "react";
const palettes = {
  arrival: ["#9db7ac", "#e4d7ad", "#253d39"],
  grand: ["#df9da0", "#f4d9a3", "#803e4b"],
  moon: ["#416c82", "#99c8bd", "#162c50"],
  spirited: ["#d78157", "#efce93", "#445842"],
  interstellar: ["#777894", "#e4b99c", "#292a44"],
  lunch: ["#c9aa66", "#f2d6a3", "#526452"],
};
export default function Art({ id }) {
  const [bg, light, ink] = palettes[id];
  return (
    <svg
      aria-hidden="true"
      viewBox="0 0 400 240"
      preserveAspectRatio="xMidYMid slice"
    >
      <rect width="400" height="240" fill={bg} />
      <circle cx="290" cy="74" r="45" fill={light} />
      {id === "grand" ? (
        <g fill={ink}>
          {[0, 1, 2, 3, 4].map((i) => (
            <g key={i}>
              <rect
                x={72 + i * 50}
                y={100 + Math.abs(2 - i) * 15}
                width="48"
                height="140"
              />
              <circle cx={96 + i * 50} cy={100 + Math.abs(2 - i) * 15} r="24" />
            </g>
          ))}
        </g>
      ) : id === "moon" ? (
        <g fill={ink}>
          <path d="M0 184Q90 134 179 184T400 164V240H0Z" />
          {[1, 2, 3].map((i) => (
            <path
              key={i}
              d={`M0 ${190 + i * 12} Q100 ${160 + i * 12} 200 ${190 + i * 12} T400 ${190 + i * 12}`}
              stroke={light}
              fill="none"
            />
          ))}
        </g>
      ) : id === "interstellar" ? (
        <g transform="rotate(-22 200 120)">
          <circle cx="200" cy="120" r="72" fill={ink} />
          <ellipse
            cx="200"
            cy="120"
            rx="160"
            ry="16"
            fill="none"
            stroke={light}
            strokeWidth="11"
          />
        </g>
      ) : id === "lunch" ? (
        <g fill={ink}>
          {[0, 1, 2].map((i) => (
            <rect
              key={i}
              x="134"
              y={96 + i * 34}
              width="132"
              height="30"
              rx="10"
            />
          ))}
          <path
            d="M174 95V82Q200 52 226 82V95"
            fill="none"
            stroke={ink}
            strokeWidth="7"
          />
        </g>
      ) : (
        <>
          <path
            d="M0 180L66 150 128 171 215 128 301 164 400 110V240H0Z"
            fill={light}
          />
          <path d="M0 206L88 173 153 188 277 149 400 177V240H0Z" fill={ink} />
          {id === "arrival" ? (
            <ellipse
              cx="172"
              cy="102"
              rx="23"
              ry="74"
              transform="rotate(14 172 102)"
              fill={ink}
            />
          ) : (
            <path
              d="M103 133H258L235 116H127ZM131 133V183H140V133M220 133V183H229V133"
              fill={ink}
            />
          )}
        </>
      )}
    </svg>
  );
}
