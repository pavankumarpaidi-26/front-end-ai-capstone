# Frameclub | Capstone portfolio entry

**Brief.** Viewers often know they want something gentle or adventurous before they know a title. Frameclub turns a short description into one explainable pick from a six-film programme. It builds on the earlier discovery app because choosing a film—not obtaining more search results—was the part that still required work.

**Live application:** Production URL pending owner deployment. Do not submit a localhost or temporary preview address as the production link.

**Source:** Target repository: https://github.com/pavankumarpaidi-26/front-end-ai-capstone . This package is not yet published there; replace this note with the exact public commit or folder URL after uploading. The accompanying README covers setup, model behavior, architecture and operations.

**Evidence.** Eight passing tests, including direct unit tests for two of the four React components. A separate browser test entered “space exploration,” opened Interstellar, saved it, dismissed the dialog with Escape, reloaded and found the same film in Watchlist. See `evidence/`. Mobile Lighthouse on the local production build: performance 100, accessibility 100. axe initially flagged poster buttons: their visible catalogue numbers were missing from their accessible names. The accessible names now include both number and title. After the fix, axe reported zero WCAG A/AA violations on the tested discovery, detail and watchlist views. These results are scoped to those states and that environment, not a blanket compliance claim.

**Release checklist / sign-off**
- [x] Reproducible install, tests and optimized build prepared; no API secrets.
- [x] Browser smoke test passed; local mobile Lighthouse and before/after axe evidence captured.
- [x] Storage-failure notice, invalid persisted data handling and unknown-mood fallback implemented.
- [x] Hosting configuration and rollback procedure documented in README.
- [ ] Owner: publish these sources to the repository; record the commit and public URL.
- [ ] Owner: deploy to the existing FE-11 site if applicable, replay the smoke test, and rerun audits on production.
- [ ] Owner: enable uptime monitoring, check keyboard/screen-reader behavior, and record name/date for production sign-off.

Local verification signed off by Arena assistant. Production sign-off withheld pending the unchecked items.

**Implementation reflection (assistant-authored; personalize after your review).** The hardest decision was when not to recommend anything. A classifier over six films can always rank them, even if the viewer asks for something outside the catalog. Returning “no confident match” preserves the usefulness of the ordinary library. Next time I would write held-out mood descriptions before authoring the training phrases; the current tests prove specific behavior, not general recommendation quality. The surprising audit result was the poster button: its accessible name sounded more descriptive than its visible number, yet someone using voice control could not refer to that visible text. Including both was a smaller and better fix than removing the number from the design.
