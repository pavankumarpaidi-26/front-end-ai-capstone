# Frameclub — a private film mood finder

Start with a feeling instead of a title. Frameclub recommends one of six curated films, explains which words informed the pick, and lets the viewer inspect and save it. Inference runs entirely in the browser. There is no account, key or per-request cost.

## Run locally
Install Node 22 LTS with npm. Extract this project, open a terminal **in the directory containing package.json**, then run `npm ci` and `npm run dev`. On Windows PowerShell use `npm.cmd ci` and `npm.cmd run dev`. Open the URL printed by Vite. `npm test` runs model, data and React component tests. `npm run build` produces `dist/`; `npx vite preview --port 4173` serves it locally. No environment variables required.

## Architecture and inference
- `app.jsx`: discovery, modal details, genre/title filters and watchlist state. Stores validated film IDs under `frameclub:v1`; storage failures leave a session-only list and show a warning.
- `Mood.jsx`: accessible mood form, bounded input and result announcement. The user prompt is “Describe a mood.” Example: “I want a witty caper.” No system prompt is sent to a model provider.
- `matcher.mjs`: fits a supervised multinomial Naive Bayes text classifier on 24 original labeled phrases at module load. Each class represents one catalog film. Scores are sums of Laplace-smoothed log word likelihoods over distinct known tokens with uniform priors. Empty vocabulary overlap or a top-two log-score gap below 0.15 triggers abstention. Returns `{kind:'match', id, terms}`, `{kind:'unknown'}` or `{kind:'invalid'}`; UI resolves IDs to curated data, never model-generated film facts.
- `films.mjs`, `Art.jsx`, `style.css`: catalog, search/persistence guards, original decorative SVGs and responsive presentation. No external font or poster requests.

## Quality evidence
See `evidence/unit.txt`, `browser.txt`, `axe-before.json`, `axe.json` and the standalone `lighthouse.html`. Direct component unit tests cover Mood and Art (2 of 4 components, not 50% line coverage); the browser flow also exercises App and Details. To repeat browser checks, run a production preview on 4173, then `npm run audit` in a second terminal. The audit runner defaults to bundled Linux Chromium; elsewhere set `CHROME_PATH` to a compatible installed Chrome. On minimal Linux images Chromium may need NSS/NSPR shared libraries. Set `AUDIT_URL` to audit a deployed HTTPS instance. Reports overwrite the current `evidence` files. Automated checks do not certify all WCAG criteria.

## Deployment and operations
For an existing FE-11 Netlify site, update its connected source/base directory rather than creating a second site. Otherwise import the project into Netlify: Node 22, build `npm test && npm run build`, publish `dist`. Use the provided `netlify.toml`. No secrets required. For manual upload, deploy the contents of the separate static-site archive; automated builds are preferable for repeatability. On the public URL verify cold load, refresh and save/reload; rerun the audit against that origin. Configure a 5-minute HTTPS uptime check for `/` (expect 200 and “Frameclub”); review failed builds in Netlify's deploy log. No monitoring is currently provisioned. Rollback: select the prior verified deploy in Netlify Deploys and publish it; revert the source commit before triggering the next auto-build. Keep the watchlist key compatible.

## Limits and next steps
English-only, small training set, no negation or robust paraphrase understanding. The margin is a heuristic, not calibrated confidence. Known-word overlap may still give a poor recommendation. Search and genre browsing remain available without the model. Next: collect consented, held-out examples, evaluate abstention, and run screen-reader and hosted-device tests before expanding the catalog. Mood text is never saved or transmitted by the app.
