import Mood from "./Mood";
import React, { useState, useRef, useEffect } from "react";
import { createRoot } from "react-dom/client";
import Art from "./Art";
import { films, select, restore } from "./films.mjs";
import "./style.css";
function detailsLabel(f) {
  return `${f.year} · ${f.genre} · ${f.minutes} min`;
}
function Details({ f, close, saved, toggle }) {
  const ref = useRef(null);
  useEffect(() => {
    const el = ref.current;
    el.showModal();
    return () => el.close();
  }, []);
  return (
    <dialog ref={ref} onCancel={close} aria-labelledby="detail-title">
      <Art id={f.id} />
      <section>
        <small>FILM NOTES / FRAMECLUB</small>
        <h2 id="detail-title">{f.title}</h2>
        <p>
          {detailsLabel(f)}
          <br />
          Directed by {f.director}
        </p>
        <p>{f.summary}</p>
        <button onClick={() => toggle(f.id)}>
          {saved ? "Remove from watchlist" : "Add to watchlist"}
        </button>{" "}
        <button onClick={close}>Close</button>
      </section>
    </dialog>
  );
}
function App() {
  const [tab, T] = useState("Discover"),
    [q, Q] = useState(""),
    [genre, G] = useState("All genres"),
    [detail, D] = useState(null),
    [msg, M] = useState(""),
    [ids, I] = useState(() => {
      try {
        return restore(localStorage.getItem("frameclub:v1"));
      } catch {
        return [];
      }
    });
  const feature = films[0];
  function toggle(id) {
    const next = ids.includes(id) ? ids.filter((x) => x !== id) : [...ids, id];
    I(next);
    try {
      localStorage.setItem("frameclub:v1", JSON.stringify(next));
      M("");
    } catch {
      M(
        "Watchlist updated for this visit only. Browser storage is unavailable.",
      );
    }
  }
  function page(t) {
    T(t);
    Q("");
    G("All genres");
  }
  const list = select(
    tab === "Discover" ? films : films.filter((f) => ids.includes(f.id)),
    q,
    genre,
  );
  return (
    <>
      <header>
        <div className="brand">
          <b>◈</b> Frameclub
        </div>
        <nav>
          {["Discover", "Watchlist"].map((t) => (
            <button aria-pressed={tab === t} key={t} onClick={() => page(t)}>
              {t}
              {t === "Watchlist" ? " · " + ids.length : ""}
            </button>
          ))}
        </nav>
      </header>
      <main>
        {tab === "Discover" && (
          <article className="hero">
            <div>
              <small>● &nbsp; THE EDITOR’S PICK &nbsp; / &nbsp; NO. 01</small>
              <h1>
                Arrival<span>.</span>
              </h1>
              <p>
                A close encounter with language, time, and the things that make
                us human.
              </p>
              <button onClick={() => D(feature)}>Explore film &nbsp; ↗</button>
            </div>
            <aside>
              <Art id="arrival" />
              <label>FIG. 01 &nbsp; / &nbsp; ARRIVAL, 2016</label>
            </aside>
          </article>
        )}
        {tab === "Discover" && <Mood open={D}/>}
        <div className="catalog">
          <small>FRAMECLUB &nbsp; / &nbsp; PROGRAMME</small>
          <h2>{tab === "Discover" ? "The film library" : "My watchlist"}</h2>
          <div className="filters">
            <input
              type="search"
              aria-label="Search by title or director"
              placeholder="Search title or director…"
              value={q}
              onChange={(e) => Q(e.target.value)}
            />
            <select
              aria-label="Genre"
              value={genre}
              onChange={(e) => G(e.target.value)}
            >
              {["All genres", ...new Set(films.map((f) => f.genre))].map(
                (g) => (
                  <option key={g}>{g}</option>
                ),
              )}
            </select>
            <small>{list.length} FILMS</small>
          </div>
          <p role="status">{msg}</p>
          <div className="grid">
            {list.map((f) => (
              <article key={f.id}>
                <button
                  className="cover"
                  onClick={() => D(f)}
                  aria-label={`FC / 0${films.indexOf(f) + 1}: View ${f.title}`}
                >
                  <Art id={f.id} />
                  <span>FC / 0{films.indexOf(f) + 1}</span>
                </button>
                <div className="row">
                  <h3>
                    <button onClick={() => D(f)}>{f.title}</button>
                  </h3>
                  <button
                    className="save"
                    aria-label={"Watchlist: " + f.title}
                    aria-pressed={ids.includes(f.id)}
                    onClick={() => toggle(f.id)}
                  >
                    {ids.includes(f.id) ? "✓" : "+"}
                  </button>
                </div>
                <small>{detailsLabel(f)}</small>
              </article>
            ))}
          </div>
          {!list.length && (
            <p>
              {tab === "Watchlist" && !ids.length
                ? "Your watchlist is empty. Save a film from Discover."
                : "No films match. Try another title, director or genre."}
            </p>
          )}
        </div>
      </main>
      <footer>FRAMECLUB &nbsp; / &nbsp; INDEPENDENT FILM NOTES</footer>
      {detail && (
        <Details
          f={detail}
          close={() => D(null)}
          saved={ids.includes(detail.id)}
          toggle={toggle}
        />
      )}
    </>
  );
}
createRoot(document.getElementById("root")).render(<App />);
