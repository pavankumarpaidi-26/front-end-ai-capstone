import test from "node:test";
import assert from "node:assert/strict";
import { select, restore, films } from "./films.mjs";
test("director query tolerates case and pasted spaces", () =>
  assert.equal(select(films, "  BARRY ", "Drama")[0].id, "moon"));
test("genre and search intersect", () =>
  assert.deepEqual(select(films, "arrival", "Drama"), []));
test("corrupt or obsolete watchlists safely reset", () => {
  for (const raw of ["{", "null", "{}", "42"])
    assert.deepEqual(restore(raw), []);
});
test("restore known IDs only, without duplicates", () =>
  assert.deepEqual(restore('["arrival","old","arrival"]'), ["arrival"]));
import {match} from './matcher.mjs';
test('unseen combinations return a catalog ID and grounded explanation',()=>{for(const [input,id] of [['I want a witty caper','grand'],['quiet cooking romance','lunch'],['cosmic adventure with astronauts','interstellar'],['aliens and language','arrival'],['queer belonging','moon'],['enchanted spirits','spirited']]){const r=match(input);assert.equal(r.id,id);assert.ok(r.terms.length);assert.ok(films.some(f=>f.id===r.id));}});
test('unknown, empty and oversized requests abstain',()=>{for(const q of ['', '税','the','zxq'])assert.equal(match(q).kind,'unknown');assert.equal(match('a'.repeat(241)).kind,'invalid');});
